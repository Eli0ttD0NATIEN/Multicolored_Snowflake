var Particule = {
	init: function(x, y){
		this.x = x;
		this.y = y;
		this.h = 3;
		this.w = 3;
	},
	draw: function(){
		fill(random(0, 255),random(0, 255),random(0, 255));
		stroke(random(0, 255),random(0, 255),random(0, 255));
		ellipse(this.x, this.y, this.h, this.w);
	},
	update: function(){
		this.x -= 1;
		this.y += random(-3, 3);
	},
	finish: function(){
		return (this.x < 1);
	},
	intersects: function(snowflake){
		var result = false;
		for (var i = 0; i < snowflake.length; i++) {
			var d = dist(snowflake[i].x, snowflake[i].y, this.x, this.y);
		 	if(d < this.h * 2){
		 		result = true;
		 		break;
		 	}
		 } 
		return result;
	}
}; 