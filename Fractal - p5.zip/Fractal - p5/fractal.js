var width = 600;
var heigth = 600;
var newParticule = Object.create(Particule);
var currentParticule;
var snowflake = [];

function setup(){
	createCanvas(600, 600);
	currentParticule = newParticule;
	currentParticule.init(width/2, 0);
}

function draw(){
	translate(width/2, heigth/2);
	rotate(PI/6);
	background('black');

	while(!currentParticule.finish() && !currentParticule.intersects(snowflake)){
		currentParticule.update();
	}
		snowflake.push(currentParticule);
		currentParticule = Object.create(Particule);
		currentParticule.init(width/2, 0);

	for(var b = 0; b < 6; b++){
		rotate(PI/3);
		currentParticule.draw();
		for (var i = 0; i < snowflake.length; i++) {
			snowflake[i].draw();
		}
		push();
		scale(1, -1);
		currentParticule.draw();
		for (var j = 0; j < snowflake.length; j++) {
			snowflake[j].draw();
		}
		pop();
	}
}